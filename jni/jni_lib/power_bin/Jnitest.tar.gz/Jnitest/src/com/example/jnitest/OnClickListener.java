package com.example.jnitest;

import android.view.View;

public class OnClickListener implements android.view.View.OnClickListener {

	@Override
	public void onClick(View arg0) {
		// TODO Auto-generated method stub

	}

}
